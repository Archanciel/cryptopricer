# cryptopricer
Console application which accepts a list of date/price values for a specified cryptocurrency and a list of fiat currencies and outputs the corresponding historical and real time values in the provided fiat currencies.
